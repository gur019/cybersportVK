self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cf2f92b810027f0fcd94949d36ed8777",
    "url": "/index.html"
  },
  {
    "revision": "0e6e260cb6f98e95aa40",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "886179c8ed69aefe259b",
    "url": "/static/css/main.31a4a801.chunk.css"
  },
  {
    "revision": "0e6e260cb6f98e95aa40",
    "url": "/static/js/2.4d7bd029.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.4d7bd029.chunk.js.LICENSE.txt"
  },
  {
    "revision": "886179c8ed69aefe259b",
    "url": "/static/js/main.ca628b75.chunk.js"
  },
  {
    "revision": "c11ad13aa956eaeb5932",
    "url": "/static/js/runtime-main.248c0eb3.js"
  },
  {
    "revision": "267c8c02c89e245f99d7412808464a2f",
    "url": "/static/media/aYaRA3j1_Pc.267c8c02.jpg"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  },
  {
    "revision": "a146da262b75a9b13938c50884e2b5b4",
    "url": "/static/media/re.a146da26.png"
  },
  {
    "revision": "06ec7e5ba36375f52c6b6a9cb14d5ea5",
    "url": "/static/media/vDzbhkDMSVk.06ec7e5b.jpg"
  },
  {
    "revision": "65c19fbd7eadc13bf3c0af535d44be90",
    "url": "/static/media/с1.65c19fbd.png"
  },
  {
    "revision": "1812ca3b1640dbcc23b36b0ecb72eee6",
    "url": "/static/media/с2.1812ca3b.png"
  }
]);