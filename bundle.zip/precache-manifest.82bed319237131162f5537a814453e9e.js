self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6bd298b0d0e5925f90a162b0d50d08a3",
    "url": "/index.html"
  },
  {
    "revision": "79e83bfb543258b2be50",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "2604906216d1e361f7b2",
    "url": "/static/css/main.bebc4fc2.chunk.css"
  },
  {
    "revision": "79e83bfb543258b2be50",
    "url": "/static/js/2.fd3b6f29.chunk.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "/static/js/2.fd3b6f29.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2604906216d1e361f7b2",
    "url": "/static/js/main.ad46b09e.chunk.js"
  },
  {
    "revision": "c11ad13aa956eaeb5932",
    "url": "/static/js/runtime-main.248c0eb3.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);