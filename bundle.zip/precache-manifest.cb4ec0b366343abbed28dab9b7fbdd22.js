self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cd3b90622a87a268f82c13c850a999ca",
    "url": "/index.html"
  },
  {
    "revision": "403c699773bbbdb7f40d",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "de3a3e2677f745a7a14f",
    "url": "/static/css/main.e89ba9a6.chunk.css"
  },
  {
    "revision": "403c699773bbbdb7f40d",
    "url": "/static/js/2.eae10932.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.eae10932.chunk.js.LICENSE.txt"
  },
  {
    "revision": "de3a3e2677f745a7a14f",
    "url": "/static/js/main.c157c1b0.chunk.js"
  },
  {
    "revision": "c11ad13aa956eaeb5932",
    "url": "/static/js/runtime-main.248c0eb3.js"
  },
  {
    "revision": "2ca832a0f1e077bc50452b44c819bc25",
    "url": "/static/media/0010830-kibersport-po-russki-prognoz-na-pyat-let.2ca832a0.jpg"
  },
  {
    "revision": "93e63ba8eb7ea761955ea20f3b65c6d3",
    "url": "/static/media/1.93e63ba8.jpg"
  },
  {
    "revision": "f5ffad888cf7eb83d3d68c6215b18522",
    "url": "/static/media/123.f5ffad88.jpg"
  },
  {
    "revision": "540973e436288e19444d47b44d29f747",
    "url": "/static/media/123a.540973e4.jpg"
  },
  {
    "revision": "fffd6357f4709fed4b2eb9a40b98e6a2",
    "url": "/static/media/2.fffd6357.jpeg"
  },
  {
    "revision": "fd500bed28c49b0ff860b1a80bdc865e",
    "url": "/static/media/282253_xhdrgf.fd500bed.jpg"
  },
  {
    "revision": "8323b657550152f24c90f35d4fadbb7a",
    "url": "/static/media/3.8323b657.jpg"
  },
  {
    "revision": "268856c561e08028958eef8c32e3fb83",
    "url": "/static/media/4.268856c5.jpg"
  },
  {
    "revision": "2f3ace34375c65afab9daa614bc88161",
    "url": "/static/media/5.2f3ace34.jpg"
  },
  {
    "revision": "510c5d5efe1e9e4aeedd1cfe147ee8ed",
    "url": "/static/media/6a01c68feedf07718ab19f98377052e4_ce_4669x2915x0x100_cropped_960x600.510c5d5e.jpg"
  },
  {
    "revision": "a2c893729154bad53a350b8fa794c4e3",
    "url": "/static/media/Dnui1CmWkAA83WK-min.a2c89372.jpg"
  },
  {
    "revision": "13f0059342af6e1c42752f9901762519",
    "url": "/static/media/WzMVv1RTA-min.13f00593.jpg"
  },
  {
    "revision": "267c8c02c89e245f99d7412808464a2f",
    "url": "/static/media/aYaRA3j1_Pc.267c8c02.jpg"
  },
  {
    "revision": "17f3a0c8e001584f88e6b46498ad640e",
    "url": "/static/media/c44a0e44ab4bcc791a1875cb0f7f9ec9.17f3a0c8.jpg"
  },
  {
    "revision": "f70ca2f04edb50cb3b6635443c8bc5e2",
    "url": "/static/media/calendar.f70ca2f0.png"
  },
  {
    "revision": "78feece1a95ec1de0bd9156a1c097e81",
    "url": "/static/media/cybersport-on-schools.78feece1.jpg"
  },
  {
    "revision": "e4e98234410f79edca671828fa12ecf2",
    "url": "/static/media/flag3.e4e98234.png"
  },
  {
    "revision": "e4de207f7f71042396a67cb844feb2b1",
    "url": "/static/media/job.e4de207f.png"
  },
  {
    "revision": "268a40bcb539257c6b58cabb53cf84c5",
    "url": "/static/media/job1.268a40bc.png"
  },
  {
    "revision": "5ae0efa31ca421db3bbdee21dc7c3412",
    "url": "/static/media/job2.5ae0efa3.png"
  },
  {
    "revision": "2cc0ed60cf75c67e278aa88c5a124ba3",
    "url": "/static/media/kibersport-670x351-1.2cc0ed60.jpg"
  },
  {
    "revision": "4258b524c9050fc53e4e43df2bbecbf7",
    "url": "/static/media/learn.4258b524.png"
  },
  {
    "revision": "bcfdbde3778ef6ece3674fde92ab7ac1",
    "url": "/static/media/liveBroadcast.bcfdbde3.png"
  },
  {
    "revision": "1fbb405ab4b90a9f6449e58c8c93d2c4",
    "url": "/static/media/naviTM1.1fbb405a.png"
  },
  {
    "revision": "677a110a3c967123115c538d840ae992",
    "url": "/static/media/naviTM2.677a110a.png"
  },
  {
    "revision": "5a94e76a7164866b04920bb7ca4e6a81",
    "url": "/static/media/naviTM3.5a94e76a.png"
  },
  {
    "revision": "633fc2dbfdbb334074a802026bd0c598",
    "url": "/static/media/naviTM4.633fc2db.png"
  },
  {
    "revision": "447538340b2f3c71f40254b0631112bf",
    "url": "/static/media/naviTM5.44753834.png"
  },
  {
    "revision": "0a5fb013cc6a2f87a775a2ee3ec9e569",
    "url": "/static/media/nigmaTM1.0a5fb013.png"
  },
  {
    "revision": "614c85cd502938be65085eb0f733bf0c",
    "url": "/static/media/nigmaTM2.614c85cd.png"
  },
  {
    "revision": "904ac01f62e756be711d3c1f15938078",
    "url": "/static/media/nigmaTM3.904ac01f.png"
  },
  {
    "revision": "e124d39f1809e3bdc0a8226d4ccd5308",
    "url": "/static/media/nigmaTM4.e124d39f.png"
  },
  {
    "revision": "4abed82f911dc3310eac24efbdb7d713",
    "url": "/static/media/nigmaTM5.4abed82f.png"
  },
  {
    "revision": "3cac5c33fafc310d40c241b14e3199bb",
    "url": "/static/media/ogTM1.3cac5c33.png"
  },
  {
    "revision": "71437eccfe35f7607599acb94bc68cfd",
    "url": "/static/media/ogTM2.71437ecc.png"
  },
  {
    "revision": "791ebbabffb9ec8483e675911206ff2d",
    "url": "/static/media/ogTM3.791ebbab.png"
  },
  {
    "revision": "12faaca39e1bc0808819aad1d9f539b9",
    "url": "/static/media/ogTM4.12faaca3.png"
  },
  {
    "revision": "583d626092f26f1593eba0d5c9f436bf",
    "url": "/static/media/ogTM5.583d6260.png"
  },
  {
    "revision": "07311b09dc3d63a689d0e7201ac6dfc6",
    "url": "/static/media/oleg-gospodarec-NxxPdqtHtWs-unsplash-1024x604.07311b09.jpg"
  },
  {
    "revision": "b2f3cc3c03a84477c568f3016a9dcb85",
    "url": "/static/media/p1_2349446_fe582283-min.b2f3cc3c.jpg"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  },
  {
    "revision": "a146da262b75a9b13938c50884e2b5b4",
    "url": "/static/media/re.a146da26.png"
  },
  {
    "revision": "587622d119d3838ad9374196bc789098",
    "url": "/static/media/sett.587622d1.png"
  },
  {
    "revision": "9b0f52ad060ca747a4643c99444b7392",
    "url": "/static/media/star.9b0f52ad.png"
  },
  {
    "revision": "d456458ddc8224348890fb87eab1ab7b",
    "url": "/static/media/teamLogo1.d456458d.png"
  },
  {
    "revision": "c7fb38a71c1c4ecfc695708e177e5556",
    "url": "/static/media/teamLogo2.c7fb38a7.png"
  },
  {
    "revision": "6ef9144e5fdf56cc7bee7460303da41e",
    "url": "/static/media/teamLogo3.6ef9144e.png"
  },
  {
    "revision": "6197c24dae33dd7b316bf67335fd008e",
    "url": "/static/media/teamLogo5.6197c24d.png"
  },
  {
    "revision": "06ec7e5ba36375f52c6b6a9cb14d5ea5",
    "url": "/static/media/vDzbhkDMSVk.06ec7e5b.jpg"
  },
  {
    "revision": "f795357ccc95471a8e82ac0341c17d71",
    "url": "/static/media/virtusTM1.f795357c.png"
  },
  {
    "revision": "17db40036f22b41e287d0da477a9af48",
    "url": "/static/media/virtusTM2.17db4003.png"
  },
  {
    "revision": "77fa5cba0ed016b4cdceb2f6bed118ba",
    "url": "/static/media/virtusTM4.77fa5cba.png"
  },
  {
    "revision": "c9aab0a6b5fc871bce0a5cacf58fcf3f",
    "url": "/static/media/virtusTM5.c9aab0a6.png"
  },
  {
    "revision": "9b852b88ab00a7fcc9efe7a692948203",
    "url": "/static/media/woman.9b852b88.jpg"
  },
  {
    "revision": "7e17b65cb122e417c95a0f089eb55757",
    "url": "/static/media/Безымянный.7e17b65c.png"
  },
  {
    "revision": "65c19fbd7eadc13bf3c0af535d44be90",
    "url": "/static/media/с1.65c19fbd.png"
  },
  {
    "revision": "1812ca3b1640dbcc23b36b0ecb72eee6",
    "url": "/static/media/с2.1812ca3b.png"
  }
]);